function createHours(data) {
  console.log('user data:', data);
  const knexQuery = knex('operating_hours');
  return knexQuery.insert({ name: data.name }).returning('id');
}

function listAll() {
  return knex
    .select('*')
    .from('operating_hours')
    .timeout(1000);
}

function getHours(id) {
  console.log('fetching one client');
  const knexQuery = knex('operating_hours');
  return knexQuery.where({ id: id });
}

function updateHours(id, data) {
  console.log('updating client', data);
  const knexQuery = knex('operating_hours');
  return knexQuery.where('id', id).update(data, '*');
}

function deleteHours(id) {
  console.log('deleting client', id);
  const knexQuery = knex('operating_hours');
  return knexQuery.where('id', id).update({ active: 0 });
}

module.exports = {
  createHours,
  listAll,
  getHours,
  updateHours,
  deleteHours,
};
