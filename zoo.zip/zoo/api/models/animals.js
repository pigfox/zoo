function createAnimals(data) {
  console.log('user data:', data);
  const knexQuery = knex('operating_Animals');
  return knexQuery.insert({ name: data.name }).returning('id');
}

function listAll() {
  return knex
    .select('*')
    .from('operating_Animals')
    .timeout(1000);
}

function getAnimals(id) {
  console.log('fetching one client');
  const knexQuery = knex('operating_Animals');
  return knexQuery.where({ id: id });
}

function updateAnimals(id, data) {
  console.log('updating client', data);
  const knexQuery = knex('operating_Animals');
  return knexQuery.where('id', id).update(data, '*');
}

function deleteAnimals(id) {
  console.log('deleting client', id);
  const knexQuery = knex('operating_Animals');
  return knexQuery.where('id', id).update({ active: 0 });
}

module.exports = {
  createAnimals,
  listAll,
  getAnimals,
  updateAnimals,
  deleteAnimals,
};
