require('dotenv').config();
const path = require('path');
const BASE_PATH = path.join(__dirname, 'src', 'server', 'db');

module.exports = {
  rows_per_page: 25,
  baseurl: process.env.BASE_URL,
  session: {
    secret: process.env.SESSION_KEY,
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 },
    activeDuration: 5 * 60 * 1000,
  },
  env: process.env.NODE_ENV || 'test',
  server: {
    port: process.env.PORT || 8080,
  },
  database: {
    test: {
      client: 'mysql',
      connection: {
        host: 'localhost',
        user: 'root',
        password: '@@@@',
        database: 'apponboard',
        port: '3306',
      },
      multipleStatements: true,
      debug: false,
    },
    local: {
      client: 'mysql',
      connection: {
        host: '127.0.0.1',
        user: 'root',
        password: '@@@@',
        database: 'apponboard',
        database: 'ail',
      },
    },
    development: {
      client: 'mysql',
      connection: {
        user: 'root',
        password: '@@@@',
        database: 'apponboard',
      },
      migrations: {
        directory: path.join(BASE_PATH, 'migrations'),
      },
      seeds: {
        directory: path.join(BASE_PATH, 'seeds'),
      },
    },
    production: {
      client: 'mysql',
      connection: {
        host:
          'evox-api-mysql.cluster-ro-codtvtpds095.us-west-2.rds.amazonaws.com',
        user: 'apiadmin',
        password: '3v0xapiadmin',
        database: 'ail',
        port: '3306',
      },
    },
    requser: {
      client: 'mysql',
      connection: {
        host:
          'evox-api-mysql.cluster-ro-codtvtpds095.us-west-2.rds.amazonaws.com',
        user: 'requser',
        password: '3v0xrequser',
        database: 'ail',
        port: '3306',
      },
    },
  },
};
