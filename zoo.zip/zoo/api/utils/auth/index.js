const Client = require('../../models/clients');
const Products = require('../../models/products');

const auth = {
  checkForUser: async (req, res, next) => {
    const apiKey = req.headers['x-api-key'] || req.query.api_key;

    if (!apiKey || apiKey === null || apiKey.length !== 32) {
      return res.status(400).json({ message: 'Invalid API key' });
    }

    let api_client_id = req.session[apiKey];

    if (api_client_id === undefined || !(0 < api_client_id)) {
      await Client.checkApiKey(apiKey)
        .then(data => {
          console.log('API key verified');
          req.session[apiKey] = data[0].id;
          req.session.clientId = data[0].id;
          req.session.base_url = data[0].base_url;
          req.session.admin = data[0].admin;
          next();
        })
        .catch(err => {
          console.log('Unauthorized API Key');
          res.status(401).json({
            message: 'Unauthorized API Key',
          });
        });
    } else {
      req.session.clientId = api_client_id;
      next();
    }
  },
  clientProductAccess: async (req, res, next) => {
    Products.getProductsByClient(req.session.clientId).then(p => {
      if (p[0] !== undefined) {
        req.session['available_products'] = p[0];
        // console.log('Client products:', req.session['available_products']);
        next();
      }
    });
  },
};

module.exports = auth;
