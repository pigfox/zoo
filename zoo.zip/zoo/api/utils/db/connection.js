const config = require('../../config');

const knexConfig = config.database[config.env];

module.exports = require('knex')(knexConfig);
