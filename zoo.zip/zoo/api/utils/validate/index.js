const validator = require('validator');

const validate = {
  vifnum: vifnum => {
    return validator.isInt(vifnum, { allow_leading_zeroes: false });
  },
};

module.exports = validate;
