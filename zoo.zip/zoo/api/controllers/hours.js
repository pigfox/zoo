const db = require('../models/hours');
const validator = require('validator');

exports.list = async (req, res) => {
  try {
    //let { name } = req.query;
    await db
      .listAll()
      .then(hours => {
        // Hide api_key from response data
        hours.map(hours => {
          //delete client.api_key;
        });
        res.json({
          status: 'success',
          data: hours,
        });
      })
      .catch(err => {
        console.log(err);
        res.status(404).json(err.errors);
      });
  } catch (err) {
    console.log(err);
    res.status(422).json(err.errors);
  }
};

exports.post = async (req, res) => {
  let data = req.body;
  const trimmedName = data.name.trim();
  if (
    trimmedName == undefined ||
    validator.isEmpty(trimmedName) ||
    Object.prototype.toString.call(trimmedName) != '[object String]'
  ) {
    return res.status(422).json('Name must not be empty');
  }

  try {
    await db
      .createHours(data)
      .then(client => {
        res.json({
          status: 'success',
          message: 'New client created',
          _id: client[0],
        });
      })
      .catch(err => {
        console.log(err);
        res.status(500).json(err.errors);
      });
  } catch (err) {
    console.log(err);
    res.status(422).json(err.errors);
  }
};

exports.put = async (req, res) => {
  let data = req.body;
  const open = data.open.trim();
  const close = data.close.trim();

  if (req.params.id == undefined || !validator.isInt(req.params.id)) {
    return res.status(422).json('Invalid client ID');
  }

  if (
    open != undefined &&
    (validator.isEmpty(open) ||
      Object.prototype.toString.call(open) != '[object String]')
  ) {
    return res.status(422).json('Open must not be empty');
  }

  if (
    open != undefined &&
    (validator.isEmpty(close) ||
      Object.prototype.toString.call(close) != '[object String]')
  ) {
    return res.status(422).json('Close must not be empty');
  }

  try {
    await db
      .updateHours(req.params.id, data)
      .then(client => {
        res.json({
          status: 'success',
          client: client[0],
        });
      })
      .catch(err => {
        console.log(err);
        res.status(500).json(err.errors);
      });
  } catch (err) {
    console.log(err);
    res.status(422).json(err.errors);
  }
};

exports.delete = async (req, res) => {
  if (req.params.id == undefined || !validator.isInt(req.params.id)) {
    return res.status(422).json('Invalid client ID');
  }

  try {
    await db
      .deleteHours(req.params.id)
      .then(client => {
        res.json({
          status: 'success',
          message: 'Client inactive',
        });
      })
      .catch(err => {
        console.log(err);
        res.status(500).json(err.errors);
      });
  } catch (err) {
    console.log(err);
    res.status(422).json(err.errors);
  }
};

exports.get = async (req, res) => {
  try {
    await db
      .getHours(req.params.id)
      .then(client => {
        res.json({
          status: 'success',
          data: client[0],
        });
      })
      .catch(err => {
        console.log(err);
        res.status(404).json(err.errors);
      });
  } catch (err) {
    console.log(err);
    res.status(422).json(err.errors);
  }
};