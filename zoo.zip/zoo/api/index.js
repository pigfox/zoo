var fs = require('fs');
var path = require('path');
var cors = require('cors');
var logger = require('morgan');
var express = require('express');
var createError = require('http-errors');
var session = require('express-session');

const config = require('./config');

var api = express();
var HTTP = process.env.PORT || 8080;
var HTTPS = process.env.PORT || 8443;

api.use(logger('dev'));
api.use(session(config.session));
api.use(express.json());
api.use(express.urlencoded({ extended: false }));

api.use(cors());

api.listen(HTTP, err => {
  if (err) {
    process.exit(1);
  }
});

api.listen(HTTPS, err => {
  if (err) {
    process.exit(1);
  }

  // instantiate connection to db
  knex = require('./utils/db/connection');
  fs.readdirSync(path.join(__dirname, 'routes')).map(file => {
    require('./routes/' + file)(api);
  });
});

module.exports = api;

console.log('EOF');



/*
Create a well managed and organized zoo management system  for your populated zoo with a UI to use it.
With NodeJS or GoLang hook to DB of your choice. There should be a simple UI layer as well to represent this data.
This code must be in a github repository that you can share with us upon completion. 
As this is fairly open ended please just make it as far as you can.

The zoo must have operating hours
There must be zoo staff
There must be zoo animals
Zoo staff must be able to change the times the zoo is open.
Zoo staff can add animals
Zoo staff must have days they are working
Zoo must always be staffed.

Min staff = 5
Max animals = 20

------------------------------------

If you knock out the base requirements, show us where you would go from here.

What other parameters might a zoo have, is there a zoo budget? 
Are the animals kept together, are there display areas, maybe a vending place or food stands? Do you charge for your zoo or is it free? 
If it's free how do you pay your 'staff', maybe some are volunteers?

Find ways to represent your decisions in your data and application layers.
Please upload your final commit no later than 3hrs

We should be able to replicate ( run ) your work based on your github repositories state after the time limit. 
Please make sure to submit all planning documentation if you generate any, or any other thought collection you may do during this time to help expose us to your thought process and how you came to certain decisions.

Docker containers will get you bonus points but is not necessary. 
If this isn't something you're familiar with please don't spend time on it because this IS a TIMED exercise
*/