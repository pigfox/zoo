const Hours = require('../controllers/hours');

module.exports = api => {
  api.route('/api/v1/hours').get(Hours.list);
  api.route('/api/v1/hours').post(Hours.post);
  api.route('/api/v1/hours/:id').put(Hours.put);
  api.route('/api/v1/hours/:id').delete(Hours.delete);
  api.route('/api/v1/hours/:id').get(Hours.get);
};
