1. Import database.sql
2. Run npm install in folder api
3. Run nodemon index.js in folder api
4. Run index.html in folder ui, click hours
It display the hours of operation.

Note. 
The api works for:

GET http://127.0.0.1:8080/api/v1/hours

PUT http://127.0.0.1:8080/api/v1/hours/1
Headers: Content-Type: application/json
Body: {"open":"09:00","close":"18:00"}